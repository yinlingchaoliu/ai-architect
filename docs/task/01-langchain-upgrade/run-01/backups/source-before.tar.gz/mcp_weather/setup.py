from setuptools import setup, find_packages

setup(
    name="mcp_server_weather",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    zip_safe=False,
)