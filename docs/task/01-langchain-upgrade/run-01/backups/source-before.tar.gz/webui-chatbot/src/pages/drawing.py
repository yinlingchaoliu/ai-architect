from openai import OpenAI
import streamlit as st
from utils.env import setDefaultEnv,getBaseUrl,getApiKey

@st.cache_resource
def get_openai_client(url, api_key):
    '''
    使用了缓存，当参数不变时，不会重复创建client
    '''
    client = OpenAI(base_url=url, api_key=api_key)
    return client


#定义了drawing_page函数，设置页面标题和说明文字。
def drawing_page():
    st.title("Drawing（文生图）")
    st.caption("use DALL·E 3 to draw images")

    # 初始化参数
    setDefaultEnv()
    base_url = getBaseUrl()
    api_key = getApiKey()

    if api_key is None:
        st.error("Please enter your API key in the home.")
        st.stop()

    #使用Streamlit的selectbox组件创建下拉菜单，让用户选择图像尺寸、质量和生成图像的数量。
    image_size = st.selectbox('image size', ["1024x1024", "1024x1792","1792x1024"], key='image_size')
    quality = st.selectbox('quality', ["standard", "hd"], key='quality')
    num_images = st.selectbox('num_images （dall-e-3 only n=1）', [1], key='num_images')
    
    if prompt := st.chat_input("prompt"):
        st.chat_message("user").write(prompt)
        with st.chat_message('assistant'):
            with st.spinner('Thinking...'):
                try:
                    client = get_openai_client(base_url, api_key)
                    response = client.images.generate(
                        model="dall-e-3",
                        prompt=prompt,
                        size=image_size,
                        quality=quality,
                        n=num_images,
                    )
                    
                    #print(response)
                    for image in response.data:
                        image_url = image.url
                        revised_prompt = image.revised_prompt
                        st.image(image_url, caption=prompt, width=200)

                        # 添加下载链接
                        download_link = f'<a href="{image_url}" download>Download</a>'
                        st.markdown(download_link, unsafe_allow_html=True)
                        # 显示提示词
                        st.write("revised_prompt : "+ revised_prompt)
                except Exception as e:
                    st.error(e)
                    st.stop()

if __name__ == "__main__":
    drawing_page()