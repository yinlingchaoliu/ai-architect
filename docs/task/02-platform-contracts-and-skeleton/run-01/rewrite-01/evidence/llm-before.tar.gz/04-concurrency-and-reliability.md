# 04 · 多用户并发、高性能与可靠性

日期：2026-11-12。状态：proposed。所有容量数字均为**待验证假设/验收候选**，当前实测 RPS、并发容量、p95 与成本均为 null。本轮未运行性能实验。

## 1. 多用户隔离和资源模型

认证后每次调用固定 tenant/subject/charge account/model ref/Run grant；一用户可并发多个模型，一模型可服务多个用户。共享连接池不共享消息历史、tools、provider headers、continuation 或取消信号。调用数据采用不可变对象，缓存/持久外键带 tenant 与授权域；对话记录由上层 Context/Session 服务提供，不在 ModelService 存一个全局 conversation。

限额同时作用于：tenant → user → Run（存在时）→ model/deployment/provider account → replica。厂商按组织账户共用配额时，多个 key/endpoint 仍归入同一 quota_group，不能把每个 key 都当独立满额来倍增容量。BudgetAuthority 的钱额度与 RPM/TPM/并发分别检查。

## 2. 准入算法与公平性

1. 请求先做身份、幂等、能力/大小/上下文校验，再进入按 tenant 分组的有界短队列。使用 weighted deficit round-robin 候选，按估算 tokens/运行时长设成本权重，长请求采用 aging，防止一直被小请求挤压。权重由管理配置发布，用户不能自报高优先级。
2. 每租户/用户队列和全进程队列均设上限；排队使用原 deadline，达到上限立即 OVERLOADED/RATE_LIMITED，不无限 asyncio.create_task。用户等待中的请求不会持有长时间厂商连接或预算。
3. 到达调度点后原子获取全局速率/并发短期许可，再在有界 DB 事务里预留预算。无余额/DB 故障/超时释放许可；事务完成时许可已失效则不发送并补偿未发送预留。不得持有锁等模型返回，也不靠分布式 Redis+PG 事务“天然原子”。
4. 真正发送前再次核对撤销、预算 grant、owner/deadline；记录 ModelAttempt 的 dispatch intent。崩溃窗口按 unknown 处理，见 [03](03-usage-and-billing.md)。
5. TPM 用安全估算先占用，再按供应商窗口规则核对；未知 usage 不盲目退还全部配额。RPM 一旦发送不能用失败结果消除请求次数。局部排队不改变上游限额。

Redis 原子脚本维护全局/账户/租户等 limiter，单进程 Semaphore 仅防本地资源耗尽。多副本下**本地公平队列 + 共享配额不等于全局严格公平**：首期提供租户上限/保留容量和本地公平，压测公平性偏差；若须全局有界等待保证，再由 quota_group 分片的独立准入 owner 统一排队，付出一个网络跳转和故障恢复成本。此 owner 只调度模型请求，不替代 L4 Agent Task 调度器。

Redis Cluster 多 key 原子脚本需共用 hash tag/同一 slot；首期使用单主限流实例或按 quota_group 分片，由单 authority 管理共享上限。跨分片祖先限制只能用预分配子额度等明确机制，不宣称任意跨 slot Lua 原子。Redis 故障/状态回退时新付费派发 fail-closed；本地估计不能偷偷替代全局治理。

## 3. 并发许可、租约与恢复

许可含 `permit_id, owner, epoch, quota_group, expires_at`，活动请求续租。正常结束/未发送失败幂等释放；租约失效不能证明远端推理停止。失联许可进入 suspect/隔离观察，达到受控传输关闭/停止确认或明确的安全回收策略后才释放；过早 TTL 回收可造成 zombie 请求叠加。

厂商不提供 cancel/inspect 时，只能确认本地连接关闭和自己的派发已停止，不能承诺厂商物理并发绝不超限；记录 remote_outcome=unknown 并保留可能费用。上游账户配额仍是最终边界。若实际需要严格物理并发，须使用有可查询/可停止作业 ID 的受控推理服务，并单独验收。

服务扩缩容不清空预算 hold。滚动发布先摘 readiness、停止新准入、排空到截止、关闭连接池；在途结果与未决 intent 可以从持久库恢复观察，不直接以新副本重新生成。健康/liveness 不执行收费模型请求；主动 provider probe 使用明确低额系统账户与可计费用量。

## 4. 异步 I/O、连接池和背压

主调用路径 async/await；进程复用 HTTP client 和 TLS/keep-alive；max_connections、连接等待 timeout、provider concurrency 一起设置。HTTP/2 仅在对应 endpoint 验证后启用，不把连接数等同于流并发数。避免每次用户调用新建 client、每条 token 建库/查价或执行同步文件 I/O。

- 结构化 Schema、tokenizer、文件解析或重 CPU 规则预编译/缓存；较重 CPU 工作进入有界线程/进程池，线程只能隔离阻塞，不能证明协程取消即停线程。
- 输入、tool Schema、单块、累计响应、tool arguments、在途事件 buffer 都设上限。相邻文本 delta 在小时间窗/字节阈值内合并，但不跨 tool/usage/terminal 事件重排。
- 每个流使用有界 buffer，消费变慢先背压，超出允许时间则关闭本次转发并记录；不能无限累积模型输出。参数片段必须完整合并验证后才能交工具执行。
- 调用链以 admission/first-byte/idle-read/overall deadline 分层超时，预算/配额检查也受 deadline 限制。等待和 retry 不能重新获得一份完整 timeout。
- 遥测采用有界批处理，drop_count 可观测；费用/发送意图的最小持久事实不能随遥测采样丢掉。DB 不可写时拒绝新付费请求，活动流写失败进入待补证且耗尽可用缓冲后停止，而非继续无界收费。

## 5. 重试、fallback 与取消

`retry_owner=model_service` 时：厂商 SDK 重试=0、LangChain middleware 不重试同次模型操作、GatewayDriver 的远端隐式 retry/fallback 关闭。未来 gateway 作为唯一 owner 时必须回传每次尝试的实际模型/usage/时间与统一上限；无法逐尝试观测的 profile 不接受完整费用审计验收。不能平台两次 × SDK 多次 × 网关多次叠乘。

| 情况 | 默认策略 | 费用/隔离 |
|---|---|---|
| DNS/连接在明确未发送前失败 | deadline/尝试数内 jitter backoff | 新尝试前预算确认；未发送证据成立才释放 |
| 本地 429/队列满/预算拒绝 | 返回或短等待 | 不更新厂商全局健康，不跨模型绕过用户额度 |
| 厂商 429/明确可重试 5xx | 按 Retry-After 和剩余预算有限重试 | 账户级/部署级 cooldown，不能由一个租户本地拒绝污染所有租户 |
| 已发送超时/连接重置 | unknown 默认不自动重发 | 如业务明确允许重复推理，需保留旧 hold 且有新预算；标记 duplicate_cost_risk |
| 已产生可见内容的流失败 | 保留 partial 与错误，不拼接另一模型续文 | 新生成是新 call 或显式版本化 restart，不能伪装同一流继续 |
| 权限/Schema/拒答/上下文过大 | 不做技术性 retry | 压缩、改写、审阅属于上层新步骤并计入预算 |
| 单模型熔断 | 仅选择同 revision 策略内具备所需能力的获准候选 | 不能跨地区/数据边界/账户权限降级；未允许 fallback 则失败 |

S01 的默认 DeepSeek 模型继续使用明确非思考 profile。切换模型需要同时保持工具/内容/续答能力和数据流许可；不同厂商 continuation/signed thinking 不能直接复用。仅用 endpoint 更换无法保证语义透明。

端到端取消：上层 Runtime cancel → ModelClient cancel → owner 停止新尝试 → Driver 关闭流/请求原生 cancel → 记录 requested/confirmed/unsupported/unknown → usage/费用对账。用户观察 SSE 断开不等于取消整个 Agent；模型调用自身的 consumer 提前退出则按 profile 触发 aclose/cancel 并最终化。单独 HTTP 模型流可设置 cancel_on_disconnect；Graph 运行事件订阅断线只解除订阅。二者必须明确区分。

## 6. 缓存和配置热更新

首期关闭应用响应缓存及语义缓存，避免工具副作用、跨租户内容/权限和计费混淆；供应商 prompt cache usage 仍如实采集。后续精确缓存键至少包含 tenant/授权域、规范化消息+工具 Schema、模型/配置/能力 revision、generation、output contract 与敏感数据策略。命中时 provider cost=无新请求且有证据，user charge 按独立政策，不能复制旧 usage 当本次厂商消费。语义缓存须单独质量/隔离验收。

价格、能力、路由使用本地不可变快照缓存，按 revision 切换；请求不逐 token 查远端配置。撤销使用短 TTL/订阅 invalidation + 发送前校验的明确一致性窗口；首期高敏撤销需要 authority online，无法核实时停止新发送，不以缓存长期有效绕过撤销。重试不能偷偷跟随新别名/latest。

## 7. 容量模型和候选指标

容量需由厂商 RPM/TPM、平均输出/推理时间、连接、DB/Redis、网络和客户端速度共同决定。Little's law 的估算：并发在途 `C ≈ arrival_rate × average_service_time`，使用平均值，不能用 p95 冒充平均值。

**假设样例**：20 请求/秒、平均厂商处理8秒，则平均160个在途；可用并发200只有25%平均余量，尾延迟和突发仍须测量。每次1500输入+500输出，20 RPS 约对应1200 RPM、240万 tokens/分钟，是否符合供应商配额当前 UNKNOWN。该模型不是当前项目吞吐证明。

拟实验 profile：先 50，再200，再500个在途请求；混合短/长输出、快慢消费者、10/100个租户、配额热点与多个副本。单机/多副本 CPU、内存、PG/Redis 拓扑、prompt/输出长度分布、网络 RTT 和版本必须在实验前固定。仅有大量 idle SSE 连接不能称500个实际模型请求通过。

| 指标 | 定义/候选门槛（待确认） |
|---|---|
| 新增治理延迟 | stub 固定首字节基线下，200在途，p95 增量候选 <30ms；机器未定，非承诺 |
| 公平性 | 每租户队列等待 p50/p95、饥饿次数与权重吞吐比，不只看全局平均 |
| 队列与内存 | 有界队列/流缓冲恒定上限，30分钟 soak 无线性内存增长，实际峰值待测 |
| 成本正确性 | 重复事件本地不重复扣款；未知不记零；并发预留不超发已知上界 |
| 恢复 | Redis/DB/owner 故障后不无账派发；未知请求保留证据，不重复生成 |
| 资源释放 | cancel/断流/超时后本地活动数、连接与许可回到合法状态；远端未知单列 |

缓冲预算示例：200条流×64KiB=12.5MiB 仅是流 buffer，不含请求/结果/SDK/对象开销。1MiB结果上限再乘200就是200MiB；token数越多不能只用stream buffer估算总内存。最终指标与可达规模以 [07](07-acceptance-and-review.md) 的实验回执为准，当前全部 not_run。
