# 05 · 开源参考、选型与复用边界

核验日期：2026-11-12（Asia/Shanghai）。范围：官方仓库、许可证和官方文档级调研；没有克隆运行、压测或完整源码审计。三个仓库的公开默认分支快照见 [reference-snapshot.json](reference-snapshot.json)。快照用于引用，不是推荐安装的稳定 release 或供应链安全签认。

## 1. 参考方案的层次区别

| 方案 | 官方可核实能力 | 本项目借鉴 | 采用限制/取舍 |
|---|---|---|---|
| LangChain BaseChatModel / model profiles | 模型统一接口、stream、tool/structured output 等集成与能力视图 | Bridge 的消息、工具、事件映射；复用 create_agent 工具循环 | 它不是租户余额/分布式配额系统；公共合同仍归项目，profile beta 变化隔离 |
| LiteLLM SDK / Proxy | 多厂商适配、Router、回退、virtual keys、成本/预算机制 | 长尾厂商协议复用、别名和单一重试 owner、usage 与价格映射参考 | 预算依赖数据库；账户/权限/审计仍要核对；独立进程优先，不能直接把它的对象暴露给业务 |
| Bifrost | Go 网关、兼容 API、路由、限流/预算与观测 | 多副本网关部署、插件边界、热路径和连接管理 | vendor benchmark 不等于本项目容量；集群/细粒度 RBAC 等需区分 OSS/企业版本 |
| Portkey Gateway | 多厂商网关、配置化重试/回退/负载均衡、流式与模型支持 | 版本化网关配置、适配流水线、标准化错误和对照 POC | 高级治理/部分缓存等与 hosted/enterprise 边界需单项核实；不把产品介绍全算作 OSS 能力 |

来源：[LangChain 模型接口](https://docs.langchain.com/oss/python/langchain/models)、[LiteLLM 仓库](https://github.com/BerriAI/litellm)、[Bifrost 仓库](https://github.com/maximhq/bifrost)、[Portkey Gateway 仓库](https://github.com/Portkey-AI/gateway)。这里选的是常见开源参考方向，不以下载/星数当适配质量或性能验收。

## 2. 关键参考事实与本项目决定

**LiteLLM。** 官方 Router 提供部署路由与共享 Redis 使用方式；文档也指出某些 usage-based 路由有额外 Redis 延迟。本项目首期采用简单静态/健康候选，按瓶颈再加复杂路由，不在每个 token 查配额。[Router](https://docs.litellm.ai/docs/routing)

官方 virtual keys 可绑定用户/团队并追踪费用，预算文档明确需要数据库；因此“统一入口能转发”不等于“多租户硬预算已生效”。项目 BudgetAuthority/账本保持独立权威，虚拟 key 可以用于出站隔离，不从用户填写的 user/team 参数接受身份。[Virtual keys](https://docs.litellm.ai/docs/proxy/virtual_keys)、[预算条件](https://docs.litellm.ai/docs/proxy/users)

LiteLLM 失效回退可在重试后切模型。项目要求单一 retry/fallback owner、显式能力及预算上限，跨模型尝试必须可归因；若代理隐藏中间尝试，无法通过本项目的完整计费审计。[官方回退语义](https://docs.litellm.ai/docs/proxy/reliability)

**Bifrost。** 官方文档区分 OSS 功能与 Enterprise：兼容入口、路由等可作参考，集群、身份/RBAC 等不要仅凭总览认定免费可用。其性能数字是上游自测，本项目不引用为自己的 TPS/时延。选型必须包含实际协议、usage、取消和多副本限额验证。[官方功能边界](https://docs.getbifrost.ai/overview)

**Portkey。** 官方仓库 README 同时列出开源网关与 hosted/enterprise 功能，并对部分能力作了标记。本项目借鉴配置化可靠性；角色管理、内容日志、费用治理等逐项按所选版本和许可证验收，不以“OpenAI-compatible”替代验证。[官方网关说明](https://github.com/Portkey-AI/gateway)

## 3. 许可证与快照

LiteLLM 根 LICENSE 对 enterprise 目录有独立许可说明，其他部分为 MIT；GitHub metadata 的 NOASSERTION 不能当作没有许可证。Bifrost 仓库根许可证为 Apache-2.0，Portkey Gateway 根许可证为 MIT。插件、企业目录、部署产品和依赖可有不同许可，实施时对实际依赖和镜像再核验。[LiteLLM LICENSE](https://raw.githubusercontent.com/BerriAI/litellm/main/LICENSE)、[Bifrost LICENSE](https://raw.githubusercontent.com/maximhq/bifrost/dev/LICENSE)、[Portkey LICENSE](https://raw.githubusercontent.com/Portkey-AI/gateway/main/LICENSE)

| 仓库 | 核验默认分支 commit | commit 时间 UTC |
|---|---|---|
| BerriAI/litellm | `6116adeb7415fc44b0b82aaa3cdd67b7225c733d` | 2026-11-12T01:06:15Z |
| maximhq/bifrost | `ff2e69f7f0143ab79c9de5258b90bd9c70cf347b` | 2026-11-11T14:18:33Z |
| Portkey-AI/gateway | `669825cbe89ee51569918b8f78a9db486fd69dd4` | 2026-05-25T13:54:51Z |

未锁上述网关 release、镜像 digest 或 SDK 依赖，也未声称选定版本已安全/兼容。本轮已读 S01 锁定版本只作为当前项目输入；选用新驱动依赖时另行求解，不借此设计轮自动升级。

## 4. 推荐采用路线与替代方案

| 选择 | 优点 | 代价 | 本项目判断 |
|---|---|---|---|
| 全部上层直接用某 SDK/ChatOpenAI | 初始代码少 | 治理分散、协议/usage/身份泄漏、难替换 | 不作为平台合同 |
| 仅用 LangChain model interface | 与 Graph 最顺 | 原生调用者被迫依赖框架，预算仍缺 | 作为外层 Bridge，保留能力 |
| 项目合同 + 少量原生驱动 | 边界清晰、先验证实际需求、依赖轻 | 自己维护规范化和测试 | **首期推荐** |
| 项目合同 + LiteLLM 独立网关 | 快速扩展厂商、可独立发布 | 多一跳、依赖/功能边界、逐尝试用量可见性 | **扩展 POC 优先候选**，通过矩阵再启用 |
| 项目合同 + Bifrost/Portkey | 可选不同运行栈/插件能力 | 需重新验证配置、重试和费用语义 | 同合同替换候选，不同时引入 |
| 自研完整高性能网关 | 最大控制 | 维护所有协议、长期成本高 | 暂不做；证据支持再拆 |

选择 LiteLLM 为扩展 POC 优先，是基于多厂商适配与治理参考的完整度以及当前 Python 生态的接入成本判断，属于**设计推论**；没有性能对比实验，不宣称它快于 Bifrost/Portkey。Bifrost 的语言/benchmark 也不能直接证明更适合本项目。

网关可替换验收：相同标准请求与 fake/provider fixtures → 文本/工具/Schema/流一致 → 所有尝试的 usage 可观测 → 取消/错误可区分 → 实际目标拓扑压测 → 灰度。网关默认关闭；能否启用由证据决定，不让业务代码 if provider 分支增长。

## 5. 明确不复用的职责

网关产品即使提供 MCP/Agent 功能，本设计仅消费模型调用，不把平台四种协作方式、Run owner、工具权限和业务状态迁给网关。也不将追踪平台或模型服务器当成计费权威：vLLM/Ollama 可作为自建模型后端，Langfuse/OTel 类后端可接观测；它们是否接入不改变 ModelClient/预算合同。本轮未对这些相邻产品做完整选型或部署承诺。
