# 07 · 验收设计、审阅与待确认项

日期：2026-11-12。状态：设计自审，**待用户确认**。review_mode=self_review；没有独立评审或用户接受签认。当前实际文档检查结果见 [design-validation.json](design-validation.json)，不以机械检查代替语义判断。

## 1. 用户要求映射

| 要求 | 方案落点 | 后续证明方式 |
|---|---|---|
| S02 先设计通用 ModelProvider | README + 01/02，既有 L5 下细化，保持 S02/S03/S04 边界 | 合同、可构建包、依赖方向与可运行切片 |
| 多厂商与不同模型 | Driver、能力矩阵、版本别名、网关备选 | 至少两个不同协议驱动替换，上层用例不变 |
| 内部变化不影响上层调用 | ModelClient v1、Bridge、标准消息/事件/错误 | 同一合同 fixture 跑不同驱动；不满足能力明确拒绝 |
| 消息计费等必要功能 | 03，用量/价格/成本/收费/预算/账本/对账分离 | 可复算公式、并发预留与重复事件、未知状态和账单差额测试 |
| 多用户并发，高性能与高并发 | 04，可信 context、配额树、共享 limiter、背压、连接池、容量口径 | 租户隔离、跨副本争抢、公平性、取消和性能阶梯 |
| 参考主流开源方案 | 05，官方仓库/文档/许可与快照 | 选定版本 POC；未把 vendor 宣传当实测 |
| 当前项目接入方案 | 06，真实符号到拟建模块、切片和回滚 | 旧入口回归、已迁移集合静态约束与灰度 |
| 完整方案先确认，指定目录写文档 | 全部内容只在本 llm 目录 | 本轮写集/输入 hash 不变；未创建 platform 或改其他 task |
| 不依赖未完成的 arch 技能 | 独立源码/一手资料分析和本轮检查 | 未调用项目技能生成/校验器，未修改技能或 AGENTS |

## 2. 实施验收矩阵（本轮全部 not_run）

| ID | 场景 | 通过标准 | 阶段 |
|---|---|---|---|
| C01 | 相同上层用例切不同协议/网关 | 调用方代码不改；消息/能力/错误语义保持；配置记录实际 deployment | S02 fixture，S03 真实 |
| C02 | 工具/结构化/内容块 | tool_call_id、参数 delta、Schema 子集、refusal/length 正确；不支持时发送前拒绝 | S02/S03 |
| C03 | DeepSeek 思考模式 profile | 非思考显式映射；思考路径启用前验证续答必需字段，不能丢失 | S03 |
| C04 | 事件组合和慢消费 | append delta 无重放、工具参数完整后才可执行、单终态、有界缓冲、usage 不重复相加 | S02/S03 |
| C05 | 100个并发上下文 | 租户/用户/headers/tools/history/continuation 不串；伪造 tenant、越权查询/取消被拒 | S03/S04 |
| C06 | 两副本同时争一份预算/并发 | 预留不超发已知额度；Redis总限额有效；局部失败不污染他租户熔断 | S04 |
| C07 | 同幂等键重放与不同输入 | 同输入取原 call；不同输入409；owner恢复不重复发未知请求 | S04 |
| C08 | 缓存/推理/多模态计费维度 | DeepSeek/Anthropic 等固定回执可复算；无重复 token；缺失为null；币种/price revision 固定 | S02 fixture / S04 结算 |
| C09 | 无 usage/流中断/长超时 | 执行与计费分离，保持hold/unresolved；不记0；不自动重复生成 | S03/S04 |
| C10 | 派发前/后/落库前崩溃 | dispatch intent 与unknown可回读；恢复不误判未发送；最终事务/outbox去重 | S04 |
| C11 | 多层重试/跨模型 fallback | SDK/框架/网关只有一个 owner；每次尝试独立预算usage；可见流后不拼接fallback | S03/S04 |
| C12 | 取消/租约过期/旧owner回传 | 停止新发送；区分本地停止/远端未知；旧epoch不能新派发或重复结算 | S04 |
| C13 | DB/Redis不可用与主从切换 | 新付费派发fail-closed；在途最小事实可恢复/补证；不靠遥测补全假账 | S04 |
| C14 | 配置发布、价格变更、密钥撤销 | 在途固定revision；新调用切新；撤销/重试前再次校验；旧池排空 | S03/S04 |
| C15 | 原始/重复/迟到账单 | 追加调整，不覆盖；聚合差额不造逐调用数据；用户退款不删除provider成本 | S04 |
| C16 | 响应缓存及semantic cache | 首期禁用；启用前做授权域/工具副作用/费用与质量矩阵 | 后续专题 |
| C17 | LangChain Bridge | bind_tools不修改共享模型；sync不阻塞event loop；callbacks只观测不重复收费 | S03 |
| C18 | 容量与公平性 | 固定拓扑50/200/500阶梯，记录等待分布/饥饿/连接/峰值内存；指标达标才宣称规模 | S04后 |
| C19 | 旧入口迁移和回滚 | 已迁移集合无SDK旁路；旧样例不串生产账户；回滚不重发在途call | S03/S10 |

真实模型测试必须记录 provider/模型/协议/driver revision、时间、限额、请求/结果摘要与 usage，密钥不入回执。不同厂商的业务质量另有样本集/评价规则，不以schema或延迟通过代替质量通过。未取得第二家凭据时只报告合同模拟，不把 fake 结果称作多厂商真实互通。

## 3. 观测和实验工件

Model span/审计记录关联 trace_id、call_id、runtime_attempt_id、model_attempt_id；Prometheus 标签限 provider/model alias/protocol/status 等低基数维度，user/tenant/Run ID 放受控日志/trace查询，避免指标基数爆炸。记录 admission_wait、budget_txn、connect/TTFT、inter-token latency、total duration、queue_depth、inflight、buffer_peak、retry_count、unknown_usage_count、unpriced_count、hold_age、ledger/outbox lag 和 drop_count。

Token/s 区分输出生成速率与平台聚合吞吐；RPS 区分受理、实际派发、成功完成；active streams 与 idle observer connections 分开。平台新增延迟用相同stub baseline差分，厂商TTFT单列。HTTP 200、可用连接或测试用例数量不是业务容量证据。

每次实验固定机器/进程/DB/Redis/网络/版本/工作负载、随机种子、token长度/推理profile、故障点和供应商配额；输出原始测量、分位数、异常、未完成、真实费用/未知费用。没有数据的项用null/not_run，不填0。压测回执本轮尚不存在。

## 4. 本轮设计自审结论

已定向核对当前源码、S02既有边界和S01回执，查阅官方开源仓库/许可证/功能文档；新文档显式标 proposed，未把逻辑层当当前已部署进程。确定了单一发送/重试owner、模型/业务Attempt区分、预算authority共用、原始usage与规范化分离、取消未知、配额窗口与多副本公平性的证明限制。

主要权衡：先自有合同+少量驱动，避免立即引入大型网关和全部数据库治理；增加稳定映射/测试成本，换取上层不依赖供应商。预算强约束依赖可核实预留上界和持久authority，不能同时声称“纯内存低延迟”与“跨副本绝不超支”。基于这些取舍建议用户评审通过总体架构，实施仍按分阶段证据推进。

本轮只做文档/引用/源码基线与写集核对。没有跑新的平台单测、真实provider、并发、账务、故障、生产或业务效果实验；没有渲染/视觉验收Mermaid，也没有部署上述开源产品。

## 5. 需要确认或后续补齐的输入

| 项目 | 本方案候选 | 未决影响 |
|---|---|---|
| 架构采用 | ModelClient v1 + Bridge + ProviderDriver；首期原生驱动，LiteLLM可选POC | 确认后才能推进下一设计/实现阶段 |
| 第二厂商 | 优先选一个原生协议厂商验证抽象，Anthropic为示例 | 账号/模型/额度未定，不硬编码或发起收费调用 |
| 商业收费 | 默认只记供应商成本，不启用customer charge | 售价/币种/余额或后付费/退款/税费待业务确认 |
| 目标容量和环境 | 50/200/500实验阶梯，p95增量30ms为候选 | 机器、供应商RPM/TPM、实际SLO未承诺 |
| 部署与内容保留 | 模块先行，可抽独立服务；PG+Redis在持久阶段 | 故障域、出站地域、内容/账务保留期限待环境确定 |
| task协同 | S02合同，S03接入，S04持久治理，S10旧模块迁移 | 如调整其他task先提交具体改动并确认 |

这些输入不妨碍评审当前完整方案，但会约束实施候选。本轮未默认为用户接受，也未更改其他 task 的计划或状态。
