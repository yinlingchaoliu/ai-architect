# 01 · ModelProvider 分层、职责与部署

日期：2026-11-12。状态：proposed，待用户确认。事实基线见 [源码快照](source-baseline.json)，实施映射见 [06](06-project-integration.md)。

## 1. 当前事实与目标

当前 `lib_graph.runtime.build_agent` 接受框架模型或字符串，图 Agent、LangServe 自行构造 ChatOpenAI；Manus、旅行、MCP router、讨论系统则直接使用 SDK。S01 解决版本兼容，尚未建立统一模型治理。源码没有 `platform/` ModelProvider 实现；S01 的真实 DeepSeek 冒烟是历史有限兼容证据，本轮没有重跑。

目标是在既有六层架构的 L5 细化 ModelGateway/ModelProvider 资源边界。命名约定：**ModelProvider 是专题/逻辑模块，ModelClient 是上层端口，ModelService 是用例实现，ProviderDriver 是厂商端口，GatewayDriver 是可选网关驱动**。不新增一层 Agent 调度器。

## 2. 逻辑架构与依赖

```mermaid
flowchart TB
    subgraph UP["调用方：Agent Harness / Graph / 普通业务"]
        H["Harness / Runtime"]
        G["LangChain create_agent / LangGraph"]
        B["独立模型用例"]
    end
    G --> LC["LangChainModelBridge"]
    H --> C["ModelClient v1 稳定端口"]
    B --> C
    LC --> C
    subgraph MP["拟建 ModelProvider 逻辑模块，属于 L5"]
        C --> S["ModelService：准入与单次模型调用"]
        S --> R["能力校验 / 固定路由快照"]
        S --> Q["公平准入 / 并发与速率"]
        S --> U["Usage 标准化 / 费用结算"]
        R --> D["ProviderDriver 端口"]
    end
    D --> A["DeepSeek 兼容协议适配器"]
    D --> N["原生厂商适配器"]
    D -.-> X["可选 GatewayDriver"]
    X -.-> GW["LiteLLM / Bifrost / Portkey，择一验证"]
    A --> V["外部模型服务"]
    N --> V
    GW --> V
    CP["L2 配置 / ModelCatalog / 策略发布"] -.-> S
    RT["L4 BudgetAuthority / 调用授权"] -.-> S
    S --> PG["L6 PostgreSQL：调用、预算、账本、outbox"]
    Q --> RD["L6 Redis：多副本限流与许可"]
    S --> SEC["L6 SecretResolver / 遥测 / 工件引用"]
```

图例：全部新节点为拟建；实线为执行调用/基础设施访问，虚线为配置授权输入或可选网关路径。逻辑模块不是独立进程清单。

| 内部边界 | 自己负责 | 不拥有的事实 |
|---|---|---|
| contracts.models.v1 | 纯数据、协议、稳定错误、消息和能力 | 不导入 LangChain、FastAPI、厂商 SDK、数据库 |
| application.models | ModelService、准入/路由/单次操作、最终化 | 不编排 Agent 工具循环，不修改 Run/Task 成功状态 |
| domain.models | 能力规则、费用维度、价格和预算规则 | 不发网络请求、不解析 JWT、不操作 Redis |
| adapters.models | 厂商协议和可选网关驱动、LangChain 桥接 | 不自行创建平台权限或业务重试 |
| infrastructure | DB/Redis/Secret/出站 HTTP、遥测实现 | 不决定业务工具执行和协作策略 |
| bootstrap / api | 注入依赖、认证、装配部署角色 | 不在 HTTP handler 中塞入全部模型逻辑 |

上层依赖 ModelClient；应用依赖 BudgetAuthority/UsageStore/ProviderDriver 等 port，基础设施实现 port。LangChainModelBridge 是外层消费者：`create_agent → Bridge → ModelClient → Driver`；原生 SDK 调用方可直接消费 ModelClient。禁止形成 `Bridge → ProviderDriver → Bridge` 回环。

ModelCatalog 与配置发布属于 L2；调用方取得的身份、Run 剩余预算权限来自 L1/L4。模型层拥有模型调用和费用观察，L4 拥有业务 Run/Task/Attempt 状态。`model_attempt_id` 与 Runtime `attempt_id` 是不同主键。

## 3. 核心模块

| 模块 | 主要行为 | 扩展点 |
|---|---|---|
| ModelCatalog | 发布模型/部署/能力/价格/路由候选，按权限查询 | 版本仓库、厂商模型发现仅作候选输入 |
| CapabilityValidator | 校验模态、工具/JSON Schema 子集、上下文和参数组合 | adapter-specific validator，unsupported 明确拒绝 |
| RouteResolver | 从允许的固定候选选择部署，记录实际模型及原因 | 静态优先，后续加权/健康路由；质量策略由上层给允许范围 |
| AdmissionController | 可信身份、多维配额、队列、公平性和许可 | 单机 adapter / Redis adapter，不能扩大预算授权 |
| BudgetAuthority | 统一预留、提交、释放、未知和撤销检查 | S02 port；S04 PostgreSQL 实现；不另建与 L4 竞争的余额 |
| InvocationCoordinator | 一个逻辑请求及有限 ModelAttempt，deadline/取消/最终化 | Direct/Gateway 两种互斥执行 profile |
| UsageNormalizer / PricingEngine | 厂商原始计数转标准维度，价格快照计算 | 未知模型/维度 pending，不硬编码单价 |
| UsageLedger / Reconciler | 去重入账、修正分录、未知对账、查询投影 | 账本同步最小事实，报表异步 |
| ProviderDriver / ClientPool | 编解码、原生流事件、异常/usage、连接生命周期 | allowlist 中预装插件，不加载租户上传代码 |

## 4. 单次调用路径

1. L1 或 Runtime 验证身份，签发不可由用户 body 伪造的 CallContext；一次 Agent 模型 turn 对应一个 logical call。
2. 幂等键核对输入指纹；同键同输入返回原调用观察，同键异输入冲突；已发送且结果未知不重新发起。
3. 固定 model/policy/route/capability/price revisions，校验请求能力、输入大小、预算授权和配置撤销。
4. 有界公平准入，获取短期许可；在受限事务时间内预留预算并持久化 dispatch intent，再确认许可仍有效后发送。失败即补偿未发送的许可/预算，见 [03](03-usage-and-billing.md)。
5. Driver 调厂商，解析内容和工具参数；ModelService 输出标准增量并记录最终 usage。工具实际执行仍由 Harness/LangChain 负责。
6. 最终结果引用与账本/outbox 同事务提交；返回执行结果及独立结算状态。模型输出通过不代表费用已经可核实，反之收费也不代表输出通过验收。
7. 未知调用由对账进程查询可用的 provider receipt；不支持查询时保留 unresolved，不能以超时自动归零或无条件重发。

### 调用时序（拟建）

```mermaid
sequenceDiagram
    participant A as Agent / Graph
    participant M as ModelService
    participant Q as Admission / Redis
    participant DB as Budget / PostgreSQL
    participant P as ProviderDriver / 厂商
    A->>M: generate / stream，可信 Context 与幂等键
    M->>M: 认证授权、能力、配置与价格 revision
    M->>Q: 有界公平队列，申请短期许可
    Q-->>M: 许可或拒绝
    M->>DB: 原子预留预算并写 Call / ModelAttempt
    DB-->>M: reservation_id / dispatch intent
    M->>P: 明确模型与超时，SDK 隐式重试关闭
    P-->>M: 内容增量 / 工具参数 / usage
    M-->>A: 有序 delta，工具参数未完成前不可执行
    alt 有可核实最终结果
        M->>DB: 最终结果引用、usage、结算或待补证、outbox
        M-->>A: completed，附 settlement_status
    else 断流或发送后超时，远端状态未知
        M->>DB: outcome unknown，保留预算 hold 与待对账记录
        M-->>A: failed / canceled 观察，费用仍可能 pending
    end
    M->>Q: 释放或隔离许可，不把断线当远端停止证明
```

## 5. LangChain / Graph 接入

Bridge 拟实现锁定版本的 BaseChatModel 调用/流式接口，将 `bind_tools` 转成不可变请求模板；每次绑定返回新对象，不能修改共享模型实例的 tools、headers 或 tenant。通过 `create_agent` 原有 ToolStrategy 产生的工具 Schema 直接走工具调用合同，不在模型层再执行一个结构化输出循环。

- 异步主路径：Bridge `_agenerate/_astream` 调异步 ModelClient；同步方法只给旧脚本适配，不在运行中的 event loop 内 asyncio.run。
- AIMessage / AIMessageChunk 与标准块双向映射，保留 tool_call_id、工具参数 delta、finish reason、usage 和协议续答引用；不能把所有内容 stringify。
- `profile` 由已验证能力快照投影，不能只凭厂商 `/models` 或框架静态表授予能力。LangChain model profile 当前仍标 beta，桥接适配其版本变化。[模型接口与 profile](https://docs.langchain.com/oss/python/langchain/models)
- callbacks 只做观测；费用只由模型层最终化入账。禁止 callbacks、middleware 和网关各记一笔成本。
- Framework/SDK 的隐式 retry 关闭，统一由本层或明确选择的外部 gateway 独占；上层 Run 重放使用原调用幂等键。

## 6. 部署演进

```mermaid
flowchart LR
    U["用户 / Agent Worker"] --> API["API 认证与模型入口"]
    API --> M1["模型服务副本 A"]
    API --> M2["模型服务副本 B"]
    API --> M3["模型服务副本 N"]
    M1 --> P["Provider API"]
    M2 --> P
    M3 --> P
    M1 --> DB["共享 PostgreSQL"]
    M2 --> DB
    M3 --> DB
    M1 --> RED["共享 Redis"]
    M2 --> RED
    M3 --> RED
    DB --> REC["用量对账 / outbox 投递进程"]
    REC --> OBS["报表 / 遥测后端"]
    M1 -.-> OPT["可选外部模型网关"]
    OPT -.-> P
```

此图描述达到多副本阶段的拟部署，实线是网络/数据依赖，虚线是可选网关；不是当前项目已部署状态。第一切片可将 ModelService 嵌入 Worker/独立示例进程，复用同一合同；增加进程时切换 RemoteModelClient，仍走同一准入与账本。生产直连和远程路径必须共用账户/预算 authority，禁止进程内路径旁路治理。

连接池按 provider account/endpoint/credential version 隔离，进程内复用；用户对话/请求上下文不放连接池。跨租户共享的只有获准平台凭据连接，不共享用户历史或可变鉴权头。网关独立进程隔离第三方依赖，沿用 S01 LangServe/MCP 的分组事实，不把新的网关依赖强装进所有样例。

拆为独立 Model Gateway 的触发条件：多个 Worker 池需要统一配额、凭据出站边界、独立扩缩容或隔离发布。是否采用 Go/Rust 网关由真实性能/能力测试决定，不仅凭语言和厂商 benchmark。

## 7. 边界与代价

项目需要自持稳定合同、租户授权与账本，避免被某个开源产品锁定；因此承担能力映射和一致性测试成本。首期不重写所有厂商 SDK，只做 DeepSeek 兼容驱动和第二个原生协议验证，长尾可通过 GatewayDriver 复用社区生态。高并发治理不能只靠 BaseChatModel 或 SDK；预算持久化也不能只靠遥测回调。
