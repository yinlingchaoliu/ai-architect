# 02 · 稳定调用合同、协议映射与配置

日期：2026-11-12。状态：proposed。以下接口、JSON 和配置均为**设计示例，尚未实现或生成正式 Schema**。总体边界见 [01](01-architecture.md)。

## 1. 端口与兼容规则

```python
class ModelClient(Protocol):
    async def generate(self, request: ModelRequest, context: CallContext) -> ModelResponse: ...
    def stream(self, request: ModelRequest, context: CallContext) -> AsyncIterator[ModelEvent]: ...
    async def estimate(self, request: ModelRequest, context: CallContext) -> CostEstimate: ...
    async def inspect(self, call_id: str, context: CallContext) -> CallObservation: ...
    async def cancel(self, call_id: str, context: CallContext) -> CancelObservation: ...
    async def capabilities(self, model_ref: str, context: CallContext) -> ModelCapabilities: ...

class ProviderDriver(Protocol):
    async def generate(self, request: ResolvedRequest, dispatch: DispatchContext) -> ProviderResult: ...
    def stream(self, request: ResolvedRequest, dispatch: DispatchContext) -> AsyncIterator[ProviderEvent]: ...
    async def inspect(self, receipt: ProviderReceipt) -> ProviderObservation: ...
    async def cancel(self, receipt: ProviderReceipt) -> ProviderCancelObservation: ...
    async def aclose(self) -> None: ...
```

ModelClient 是业务端口；ProviderDriver 是受治理执行端口。Driver inspect/cancel 不支持时返回 `unsupported`，不得伪造停止确认。Embedding 使用独立 `EmbeddingClient.embed(EmbeddingRequest, CallContext) → EmbeddingResponse`；维度、模型 revision、归一化方式属于向量索引合同，切换维度不能对 RAG 透明。

v1 只允许添加可选字段/能力；改变计数口径、finish reason、工具参数或流语义要升级主版本。旧客户端对未知可选事件可跳过，但未知终态/必需内容块必须报 `SCHEMA_UNSUPPORTED`，避免丢内容仍报告成功。边界值/JSON Schema 的具体子集在实施时冻结并产出正反例。

## 2. 对象与身份

| 对象 | 必需内容与语义 |
|---|---|
| CallContext | 服务端认证 tenant_id、subject_id、charge_account_ref、授权范围、trace_id、request_id、deadline、可选 run_id/task_id/runtime_attempt_id/budget_grant_ref/owner_epoch |
| ModelRequest | contract_version、model_ref、messages、generation、可选 tools/tool_choice/output_contract、metadata 的 allowlist 字段；单请求 n=1 |
| ModelResponse | call_id、message、finish_reason、可选 structured_value、UsageObservation、settlement_status、受权限控制的 serving_receipt_ref |
| ModelCapabilities | revision、input/output modalities、tools/parallel_tools/JSON Schema 子集、stream、reasoning 策略、上下文/输出限制、usage/inspect/cancel 支持及 evidence_status |
| ResolvedRequest | 原请求与不可变 model/deployment/credential/policy/capability/price revisions、dispatch 参数；仅内部可见 |
| ModelAttempt | model_attempt_id、call_id、序号、部署/厂商请求 ID、发送与首字节时间、远端观察、usage/错误引用、reservation_id |
| ProviderContinuationRef | 受租户和权限保护的协议续答引用，绑定 provider/deployment/protocol/version；不是跨厂商通用对话 ID |

context 不由模型生成，不接受 body 中 tenant_id/user_id 覆盖。metadata、LangChain RunnableConfig 和 trace baggage 都不是身份来源；Bridge 必须取得 Runtime 注入的可信 context 或由 authenticated remote client 构建。ContextVar 可便于传播，但必须 set/reset，禁止全局可变 current_user。工具参数里即使出现身份字段也不授予权限。

`request_id` 表示一次传输，`call_id` 表示一次逻辑模型操作，`model_attempt_id` 表示一次实际厂商请求。Graph 的每个模型 turn 和结构化修正都有独立 call_id；一次 call 内的供应商重试有新 model_attempt_id。父 Runtime Attempt 和模型尝试必须可关联而不复用主键。

幂等指纹由规范化请求体、调用者租户/计费身份及显式请求版本形成，不包含 trace/timestamp 等易变字段。首次成功创建 Call 的事务固定已解析 revision；同键重试先取原 Call，不因 active alias 已更新而重新路由。两个副本竞争创建时只有唯一约束胜者可持有发送所有权，败者读取原调用；UNKNOWN 不是重获发送资格。

## 3. 统一消息与能力

消息结构：`message_id, role, blocks[], tool_calls[], tool_call_id?, continuation_refs[]`。role 为 system/user/assistant/tool；developer 作为有能力声明的扩展，不能默认塞入所有厂商请求。工具结果保留 tool_call_id/is_error，system 提示词不能被工具回包覆盖。

| 内容/能力 | v1 处理 | 不支持时 |
|---|---|---|
| text | 标准 UTF-8 文本块；空文本与缺失分开 | 验证失败 |
| image/document/audio/video | MIME、受控 artifact_ref、size/hash；不在通用消息里塞无限 base64 | capability 拒绝；不得自动 OCR/转录并声称原模态支持 |
| tool_calls | ID/name/arguments 对象及来源；流中参数先是 fragment，结束后验证 | tools 不支持则发送前拒绝；不降级为“请输出 JSON” |
| JSON Schema | 显式 `native_schema` 或框架 `tool_strategy`；记录约束子集 | native 不可用且未授权策略转换则拒绝 |
| reasoning | disabled 或具名 effort/budget；受能力组合约束 | 明确拒绝；不静默忽略 temperature 等无效参数 |
| provider continuation | 不透明、安全引用，原协议回传必需内容 | 切厂商先显式重建合法历史或拒绝 fallback |
| 多模型/多部署 | model_ref 指向发布 revision，内部解析 deployment | 未发布、撤销或无权限则拒绝 |

不同厂商的 thinking/signed blocks 必须按协议保真存储或通过安全引用回传，默认不进入普通日志、账单或用户文本。DeepSeek 的工具思考路径需要往返 reasoning_content，首期继续 S01 非思考 profile，不凭一个通用 SDK 就宣布思考模式已支持。[官方思考模式](https://api-docs.deepseek.com/guides/thinking_mode/)

`capabilities.evidence_status` 取 documented / contract_tested / live_verified / disabled，分别记录查证时间、具体模型与协议版本。框架支持某项不等于所有同厂商模型都支持；`/models` 发现结果只进入候选，经过发布才可调用。[LangChain 集成能力表](https://docs.langchain.com/oss/python/integrations/chat)

## 4. 调用示例

```json
{
  "contract_version": "model.v1",
  "model_ref": "chat.general@r1",
  "messages": [{"message_id":"m1","role":"user","blocks":[{"type":"text","text":"请概括这段需求"}]}],
  "generation": {"max_output_tokens":512,"reasoning":{"mode":"disabled"}},
  "metadata": {"purpose":"requirement-summary"}
}
```

可信 context 单独携带，调用方不能通过 model_ref 绕过租户允许列表。业务可选择逻辑别名，也可显式选择获准的具名模型；无论哪种都固定 revision。首次发布中 `chat.general@r1` 只解析到 DeepSeek Flash；其他模型是候选，不表示已获凭据或实测。

```json
{
  "call_id":"call-example-1",
  "message":{"message_id":"m2","role":"assistant","blocks":[{"type":"text","text":"示例输出"}],"tool_calls":[]},
  "finish_reason":"stop",
  "usage":{"status":"missing","input_total":null,"output_total":null,"source":"unavailable"},
  "settlement_status":"pending"
}
```

该示例刻意展示 usage 缺失时仍可有执行结果，不表示真实 provider 回执或零费用。价格与收费合同见 [03](03-usage-and-billing.md)。

## 5. 流与错误

事件封套：`event_version, call_id, model_attempt_id?, sequence, type, emitted_at, payload`。sequence 在同一 call 内单调递增；正常可观测流只有一个终态。连接断开无法保证消费者收到终态，以 inspect 为准。

| 事件 | 内容/处理规则 |
|---|---|
| call.accepted / attempt.started | 已接收与实际尝试分开；accepted 不是已发厂商 |
| content.delta | block_id + append delta；不能把累计快照再次 append |
| tool_call.delta | tool index/ID + name/arguments fragments；未收齐不执行 |
| tool_call.completed | 完整参数与 schema 校验结果，仍由 Harness 决定是否执行 |
| usage.observed | delta/cumulative/final 明确标记与 observation_id；只做快照归并，不能重复相加 |
| call.completed | 最终 response_ref、finish_reason、usage_status、settlement_status |
| call.failed / call.canceled / call.unknown | 稳定错误/停止观察；不能据此假设厂商未收费 |

不暴露 provider HTTP 包、SDK chunk 或 LangGraph v3 事件为公共 wire schema。Bridge 可将标准事件投影回框架 token/tool 事件，框架最终 usage 不再二次计费。v1 默认不提供 token 流重放，Last-Event-ID 不触发新生成；断线后查询调用结果。需要持久 token 重放时另设加密事件存储和保留策略，不假装内存 buffer 能跨进程恢复。

错误封套含 `code, category, retryable, remote_outcome, call_id, safe_message, retry_after_ms?, details_ref?`：

| 错误码 | 对外语义 | 默认动作 |
|---|---|---|
| INVALID_REQUEST / SCHEMA_UNSUPPORTED | 输入/内容块/参数组合非法 | 不重试 |
| AUTH_REQUIRED / ACCESS_DENIED / MODEL_REVOKED | 身份、模型权限或紧急撤销 | 拒绝；不 fallback 到未授权模型 |
| CAPABILITY_UNSUPPORTED / CONTEXT_TOO_LARGE | 合同要求超过模型能力 | 拒绝；压缩是显式上层步骤且另计调用 |
| IDEMPOTENCY_CONFLICT | 同租户同键不同请求指纹 | HTTP 409；不发送 |
| BUDGET_EXCEEDED / PRICE_UNAVAILABLE | 无预算或无法形成安全预留 | 拒绝或管理员授权的独立开发 profile |
| RATE_LIMITED / OVERLOADED | 本地配额/队列满，或注明上游 429 | 有界等待/返回 Retry-After；不误触全局熔断 |
| PROVIDER_UNAVAILABLE / PROVIDER_PROTOCOL_ERROR | 上游明确失败或协议异常 | 由唯一重试 owner 判定 |
| DEADLINE_EXCEEDED / CANCELED / OUTCOME_UNKNOWN | 截止/停止/远端未知 | 关闭传输、记录/对账；不默认重发 |
| OUTPUT_INVALID | 结构化结果未通过 | 记录费用；修正调用由上层显式授权 |
| LEDGER_UNAVAILABLE / ADMISSION_UNAVAILABLE | 必需持久化/配额服务不可用 | 新付费发送 fail-closed |

拒答、长度截断、工具调用终止分别映射 `refusal/length/tool_calls` finish_reason；业务用例是否接受截断由上层决定。原始错误受控保存，不把厂商响应中的密钥、URL 查询或提示词回显给用户。

## 6. 可选 HTTP 与管理接口

首期同进程端口先实现；远程入口共享相同用例，不复制治理逻辑。

| 拟建接口 | 身份/幂等/返回 |
|---|---|
| POST /v1/model-calls:generate | Bearer/服务身份，Idempotency-Key 必需；成功 ModelResponse，失败稳定错误 |
| POST /v1/model-calls:stream | 同上，SSE；HTTP 建流前可用状态码，建流后使用标准失败事件 |
| GET /v1/model-calls/{call_id} | 按 tenant/subject/审计权限查询；包含调用与结算两个状态 |
| POST /v1/model-calls/{call_id}:cancel | 同一调用可重复请求；返回 requested/confirmed/unsupported/unknown |
| GET /v1/models | 仅允许模型/能力/版本视图，不包含凭据或账户配额秘密 |
| POST /internal/model-configs:validate / :publish / :revoke | 管理身份和审计；compare-and-swap revision；与普通用户 API 隔离 |
| GET /v1/usage | 按调用者权限聚合，cursor 分页；有 as_of/watermark/unknown_count，不拿异步报表当实时余额 |

S02 身份外壳未接真实认证时只能使用具名 local-test context，禁止作为多用户生产入口。取消/查询 ID 必须重新授权，不靠 UUID 难猜作为隔离。

## 7. 配置和插件生命周期

```yaml
# 拟配置形状，未实现或发布
schema: model-config.v1
revision: models-r1
providers:
  deepseek-primary:
    driver: openai_compatible_v1
    endpoint_ref: endpoint/deepseek-official
    credential_ref: secret/deepseek/platform-key@v1
    protocol: chat_completions
models:
  chat.general:
    revision: r1
    candidates:
      - deployment_ref: deepseek-primary/flash-r1
        provider_model: deepseek-flash
        capability_ref: caps/deepseek-flash-nonthinking@r1
        price_ref: prices/deepseek-flash@pending-verification
    required: [text_in, text_out]
    reasoning: disabled
    fallback: disabled
policies:
  retry_owner: model_service
  sdk_retries: 0
  application_response_cache: disabled
```

`pending-verification` 是设计占位；生产发布验证必须拒绝未核实价格，不能把它当已存在的价格表。endpoint_ref 来自管理员 allowlist，普通用户不能提交任意 base_url 或 header。不同租户 BYOK 需独立 credential namespace、授权绑定和池，用户也不能指定另一个租户的 secret_ref。

发布过程：draft → 静态校验/出站和密钥引用校验 → 合同与受控 canary 验证 → 原子切 active revision。新调用绑定新 revision，在途调用保持原快照；紧急权限/密钥撤销在发送及重试前重新检查。回滚只改变新请求指针，不重放在途调用，不改写历史价格。别名可能由厂商更新实际模型，保存 provider 返回的 resolved_model/version；未提供时标 unknown，并对能力漂移告警。

插件只允许已审查、已安装、已锁版本的 driver_id。动态注册是“发布已有驱动的配置实例”，新增协议实现仍需代码发布；不允许租户上传 Python 路径/代码、任意 pip install。客户端池带 credential_version 引用计数，轮换后新调用用新池，旧池排空/撤销后关闭。所有配置变更写审计，不记录 secret 原文。
