# 03 · 消息用量、预算、计费与对账

日期：2026-11-12。状态：proposed。本文是软件账务设计，实际供应商合同、售价、币种、充值/退款和税费政策均为 UNKNOWN，不能据此直接向用户收费。

## 1. 计费对象与事实分开

“消息计费”首选以**一次实际模型请求**采集 usage，再按 message/call/Run/用户/租户归因；不能简单按消息条数收费。多轮请求会重复发送历史上下文，每次处理的历史 tokens 都可能计费；message_id 只提供归因，不据此全局去重计费。usage 是请求级时，不能伪造每条消息的精确实际 token 分摊，只能单列 allocation_method=estimated。

| 事实 | 记录与唯一写入者 |
|---|---|
| Provider usage | 原始厂商观察、normalizer revision；UsageCollector 接收，保留缺失/不一致 |
| Provider cost | 每个 ModelAttempt 的价格快照和可复算成本；PricingEngine + Ledger |
| Customer charge | 独立 charge policy revision/分录；只有业务定价明确后启用，默认 disabled |
| Budget reservation | 额度占用及释放/结算；统一 BudgetAuthority，L4 与模型层共享同一授权树 |
| Reporting / tracing | 账本的异步投影；不可直接改余额，trace 缺失不等于没有费用 |

失败尝试、fallback、结构化修正和探测只要实际发生厂商请求都可能产生费用。平台不承诺上游 exactly-once；保证的是**本地同一账务事件不重复入账、未知远端结果不误记零**。用户端免费或退款不会抹掉实际供应商成本，需分别记补贴/冲正分录。

## 2. 标准 usage 口径

UsageObservation 含 `observation_id, call_id, model_attempt_id, status, source, normalizer_revision, observed_at, raw_receipt_ref`。status=estimated/partial/final/missing/inconsistent；来源 provider/gateway_estimate/local_estimate/invoice_reconciled。计数为非负整数或 null，未知不填 0。

标准 token 轴：`input_total, input_uncached, input_cache_read, input_cache_write_by_ttl, output_total, output_reasoning, output_visible?, total_tokens`。input 的互斥分桶与 output 的分析子集分开；不是把所有字段相加。多模态和请求费使用独立 `billable_units[{dimension,quantity,unit,source}]`，避免将图片张数、音频秒数强行加到 tokens。

| 厂商差异 | 规范化规则与证据 |
|---|---|
| DeepSeek 缓存 | prompt_tokens 为总输入，hit/miss 是其拆分；不能再把 hit 加到总输入。输出以 completion_tokens 为主，reasoning 若已包含于输出不能重复计。[Chat API](https://api-docs.deepseek.com/api/create-chat-completion/) |
| Anthropic 缓存 | 官方 input_tokens 为未读/未写缓存的输入；总输入需要加 cache_read 与 cache_creation，写缓存可按 TTL 分桶。[官方缓存 usage](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) |
| OpenAI 兼容协议 | 只代表线协议兼容，不推断 usage/缓存/推理细节相同；每个 driver+协议版本有独立 mapping fixture，未核验字段留 null |
| 流式事件 | 声明 delta/cumulative/final；累计值覆盖较旧快照，不把 chunk usage 相加；最终 usage 缺失保持 partial/missing |
| 自建推理 | 记录服务 usage，供应商 API 成本可为不适用；GPU/容量摊销是独立计价模型，不能把没公开单价当免费 |

DeepSeek 示例：prompt=1000、hit=600、miss=400、completion=100、其中 reasoning=40，则 total=1100，reasoning 不再另加 40。Anthropic 示例：input=100、cache_read=600、cache_creation=300，则标准 input_total=1000。这些为口径样例，不是真实本轮调用。若字段冲突，记录 inconsistent 并停用自动结算，保留原回执供修正。

## 3. 价格模型与费用公式

PriceRevision 不可变：`provider, provider_model, deployment/region, currency, effective_from/to, service_tier, context_tier_rule, unit_prices[], source_url, verified_at, reviewer, rounding_policy`。每个 ModelAttempt 固定实际匹配的 price_revision；仅按模型显示名查实时单价不满足审计。

```text
cost = Σ mutually_exclusive_billable_units[dimension]
         × decimal_unit_price[dimension] / explicit_unit_scale[dimension]
```

例如 input_uncached/cache_read/cache_write_5m/cache_write_1h/output 等互斥价格项；reasoning 已包含于 output_total 时是分析字段，不再作为附加价格项。只有厂商价格合同明确另收费的维度才额外计入。所有货币计算用 Decimal 或定标整数，不用 float。内部保留高精度，按固定 policy 在结算/展示处舍入；跨币种保留原币种和 FX revision，不直接相加 USD/CNY。

长上下文分档、batch/service tier、缓存 TTL、server tools 的每次请求费、图像/音频等维度都由 price rule 明确表达。模型层不会实际执行业务工具，但厂商托管的工具收费仍需捕获并归因。LiteLLM 的成本表和 Portkey pricing 数据可作为候选输入，不在运行热路径直接跟随网上 latest，也不代替当前账户的折扣合同。[LiteLLM 成本跟踪](https://docs.litellm.ai/docs/proxy/cost_tracking)

### 演算样例（虚构价格，仅用于测试公式）

设 P=2、cache_read=0.2、output=8 个货币单位/百万 tokens，输入1000其中600命中，输出100：`(400×2 + 600×0.2 + 100×8)/1_000_000 = 0.00172`。样例必须在 fixture 中标记 fictional；不能作为 DeepSeek 报价或用户账单。

价格缺失时 cost=null、pricing_status=unpriced。生产付费准入在无法形成安全上界时拒绝；本地开发无账单 profile 须显式选择、设独立限额、标记不具备生产预算保障。

## 4. 预算预留与事务边界

BudgetAuthority 是平台统一 port，S04 落地持久实现。预算可作用于 tenant/account/user/Run/Task 等范围，扣款账户与授权上限分开；同一笔钱只在一个 ledger account 扣一次，祖先预算只是同时占用的约束，不能重复收费。

每个尝试的预留上界覆盖该模型配置下的输入估算保守界、max_output_tokens、推理上界、已授权托管工具和其他收费项。跨模型 fallback 必须按新价格重新预留；已发生但费用未知的旧尝试保留 hold。tokenizer 估计不能自动称为严格上界：必须有经过验证的 envelope/厂商上限，未知无界项禁用或拒绝硬预算请求。承诺是“不超发平台可核实预留额度”，不是无条件保证未知厂商最终账单绝不超额。

原子准入逻辑：

1. 可信预算 grant 校验 tenant、charge account、Run deadline/owner、撤销和上限；模型层不能创建比父授权更大的 grant。
2. 在 PostgreSQL 同一事务按固定层级/ID 顺序锁定相关预算行，检查 `settled + active_holds + new_hold <= limit`，同时占用各约束、创建 Call/ModelAttempt/Reservation 与 dispatch intent。DB 事务中不执行厂商 HTTP。
3. 唯一约束 `(tenant_id, idempotency_key)` 和输入指纹处理重复入口；同键同输入不再发送，同键不同输入冲突。transaction retry 不允许重发厂商调用。
4. 提交后检查短期执行许可、deadline、撤销仍有效，再记录发送进度并发请求。commit 与外部发送之间崩溃无法原子化；dispatch-intent 若不能确认未发送，恢复按 unknown 对账，禁止直接再次发送。
5. 最终 usage/cost、余额变化、hold 结算、结果引用和 outbox 同事务。报表通知 at-least-once 投递，消费端按 event_id 去重；不依赖 trace callback 结账。

首个持久版本可以每个账户行串行预留/结算，但不在逐 token 热路径访问 DB。超大共享租户出现热点后，才设计 worker 子额度 escrow/grant：父预算先扣出可用子额度，子额度在分片内原子消耗，回收前确认所有权和未决请求。不能把单纯 Redis 计数或异步批量消费包装为严格不超支。

## 5. 结算状态与未知费用

```mermaid
stateDiagram-v2
    [*] --> reserved
    reserved --> released: 明确未发送或已确认不计费
    reserved --> pending: 已发送，等待完整 usage
    pending --> settled: usage 与价格维度可核实
    pending --> unresolved: 断流或用量缺失
    unresolved --> settled: 收到可信补充证据
    unresolved --> disputed: 长期无法核实，进入人工对账
    settled --> adjusted: 供应商对账产生差额分录
    adjusted --> adjusted: 新证据触发新的调整分录
    released --> [*]
    disputed --> settled: 审核后补充分录
```

执行状态与结算状态独立。流 canceled 不等于 released；租约 TTL 到期不自动释放已发尝试的费用预留。只有明确未发送、可信不收费回执或已核实结算才可释放相应金额；unknown 可以进入 disputed，后续人工决定释放/补贴时也必须有审计分录。

实际 usage 小于预留时释放差额；大于预留时如实记成本/overspend anomaly，阻止新调用并对账，不能截断实际 usage 或隐去差额。重复 provider receipt 用 `(account, provider_request_id, receipt_kind, revision)` 去重；没有稳定 provider ID 时使用本地 model_attempt_id + observation 序号，不能跨不同真实尝试按文本内容去重。

迟到账单通过追加 adjustment 引用原 settlement，不覆盖原值。币种、时间窗口、cache/service tier 与账户折扣一致后才做对账；供应商仅给聚合账单时记录账户级残差，不能编造每个调用的精准归属。无法查到单次回执时，人工对账/保留未知是正式状态，不是后台自动“修正成成功”。

## 6. 拟建持久模型

| 表/集合 | 关键字段和约束 |
|---|---|
| model_calls | tenant_id、call_id、idempotency_key、request_fingerprint、caller refs、snapshot refs、execution_status、settlement_status、result_ref；租户内键唯一 |
| model_attempts | tenant/call/model_attempt_id、ordinal、deployment、provider_request_id、dispatch_phase、outcome、timestamps；call+ordinal 唯一 |
| model_usage_observations | attempt、observation_id、normalizer revision、status、raw_receipt_ref、标准计数；去重索引 |
| model_price_revisions | 不可变价格维度、单位、币种、来源、适用期间、校验人/时间 |
| budget_accounts / budget_constraints | charge account 与多层限额、settled/held、currency、row_version；账户不是普通用户自填值 |
| budget_reservations | reservation_id、attempt、约束引用、upper_bound、state、grant_ref；同尝试有效预留唯一 |
| cost_ledger_entries | entry_id、account、attempt、kind、amount、currency、price/usage refs、reversal_of；追加式、业务事件唯一 |
| model_outbox / reconciliation_cases | event_id、payload_ref、重投进度；未决证据、差额、owner 与解决依据 |

所有 tenant-owned 外键包含 tenant_id，查询层强制 scope；可叠加 RLS，异步 DB 池须用事务局部租户设置且归还时清理。原始 prompts/response 不作为账本必需字段，密钥永不入库；回执按最小必要字段脱敏/加密，独立内容存储有权限、保留与删除策略。usage/账务保留期限和内容保留期限分别确认，不能以删对话为由悄悄改历史账。

## 7. 查询和验收

提供按用户/租户/Run/Agent/model_ref/实际模型/日期的使用和费用视图，同时显示 unknown_count、unpriced_count、pending_hold 和 watermark。raw tokens、费用、内部 credits、预算余额和吞吐是不同指标；只有已核实 price/charge policy 才换算 credits。

必须覆盖：百个并发请求抢同一剩余额度、重复回执、多次重试/跨模型价格、发送前后崩溃、流无最终 usage、迟到账单、价格改版、币种/缓存维度、未知保留 hold、祖先预算撤销、余额超额异常。详细矩阵见 [07](07-acceptance-and-review.md)。本轮没有创建数据库或执行账务实验。
