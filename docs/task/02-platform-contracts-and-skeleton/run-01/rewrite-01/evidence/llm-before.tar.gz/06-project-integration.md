# 06 · ai-architect 接入、迁移切片与回滚

日期：2026-11-12。状态：proposed。本轮仅写本目录的设计文档；没有修改以下源码、平台目录或其他 task。输入基线 HEAD 与逐文件 hash 见 [source-baseline.json](source-baseline.json)。

## 1. 源码事实与接入点

| 当前文件/符号 | 核对事实 | 拟接入变化 |
|---|---|---|
| [lib_graph.runtime.build_agent](../../../../lib_graph/src/lib_graph/runtime.py)（22–50） | 接受框架模型/string，直接 create_agent；context 只有 request_id/user_id | bootstrap 注入 LangChainModelBridge；可信 tenant/预算/owner 从 Runtime 传入，不让模型层接管 Agent 循环 |
| [agentmcp.run_query](../../../../agentmcp/agentmcp.py)（12–38） | 自行构造 ChatOpenAI，原生 MCPAdapter 工具供 create_agent 使用 | 接受注入的 Bridge，默认模型由模型层配置；MCP 继续是工具层，不进入 ProviderDriver |
| [Manus LLMManager.generate](../../../../manus/src/llm/manager.py)（77–144） | 直接 AsyncOpenAI，自己拼 tools、response 和 usage | LegacyModelFacade 委托 ModelClient，保留 content/tool_calls 等消费形状，费用改查新账本 |
| [Manus 计费](../../../../manus/src/llm/manager.py)（146–180）与 [DTO](../../../../manus/src/llm/models.py)（6–32） | usage 缺失置零；cost float、默认单价0、固定除1000；累计数在进程 dict | 以新 UsageObservation/PriceRevision/ledger 为权威；旧统计只作明确 legacy view，不能把缺失转0 |
| [旅行 BaseAgent._call_llm](../../../../agent_muti/src/agents/base_agent.py)（50–110） | 自有重试循环；构造 AsyncOpenAI，读取 timeout 但该段请求未传入 | 注入 ModelClient，删除迁移路径上的重复 retry；deadline 从 context 到传输真正生效；同步请求日志需脱敏 |
| [图 Agent BaseAgent.call_llm](../../../../graph_discussion/agents/base_agent.py)（17–40） | 构造 ChatOpenAI，同步 invoke，异常变普通字符串 | 过渡用同步 facade；正式 Graph 切 async Bridge，并把失败转显式错误，不伪装模型文本 |
| [讨论 BaseAgent.generate_response](../../../../agent_muti_discussion/src/core/base_agent.py)（24–100） | 同步 SDK，历史保存在 Agent 实例 | 同步兼容 facade 仅旧脚本；多用户入口每次会话隔离实例/历史，向 async 模型端口演进 |
| [MCP router LLMMCP](../../../../mcp_client_manager/src/core/mcp_router.py)（11–64） | 单独 AsyncOpenAI tool routing，失败后回退帮助文字 | 模型决策请求走 ModelClient，工具执行仍归 MCP manager；技术失败与业务帮助分开 |
| [LangServe OpenAIServer](../../../../server/app/chain/openai_server.py)（25–29） | 模块装配时构造环境配置模型 | 通过远程 ModelClient/Bridge 接入独立模型服务；保留 LangServe 独立依赖组 |
| [CSV/RAG](../../../../csv-search/llm.py) 与 [PDF 页面](../../../../webui-chatbot/src/pages/pdf_search.py) | 聊天模型与 Embedding 分别构造，旧链仍存在 | S10 按既定迁移；聊天接 Bridge，Embedding 独立模型和维度/索引合同，不能用 DeepSeek 文本端点替代 |

表中事实来自本次定向源码回读，不代表完整运行验证。S01 的 [最终回执](../../01-langchain-upgrade/run-01/evidence/final-verification.json) 记录31项回归与有限真实模型检查；本轮未重跑，也不把它当成拟建多用户平台已通过。

## 2. 拟建目录与依赖方向

```text
platform/                              # 当前未创建，待授权实施
  pyproject.toml / uv.lock
  src/agent_platform/
    contracts/models/v1.py             # 请求/消息/事件/能力/错误
    application/models/
      service.py                       # 单次模型用例/最终化
      ports.py                         # Budget/Usage/Admission/Driver ports
    domain/models/
      capabilities.py / usage.py / pricing.py
    adapters/models/
      drivers/openai_compatible.py      # 首先 DeepSeek 非思考 profile
      drivers/anthropic.py              # 原生协议第二切片，候选
      drivers/gateway.py                # 可选 LiteLLM 等网关
      legacy_facade.py
    adapters/frameworks/langchain_model.py
    infrastructure/models/
      http_pool.py / secrets.py
      postgres_ledger.py / redis_admission.py
    api/model_calls.py
    bootstrap/model_resources.py
  tests/models/
    contract/ / adapters/ / concurrency/ / recovery/
```

`contracts/domain` 不依赖 SDK/框架/数据库；application 只消费 port；LangChain/SDK/基础设施依赖指向内部合同。具体模块名可在实施中小范围调整，但不能让 Run/Pattern 直接 import driver。v1 DTO 使用纯类型，API 层可用 Pydantic 验证/wire schema；不直接返回厂商 BaseModel。

首期不新增独立代码仓库，不把 `lib_graph` 扩成全平台账本，也不重写整个 LangChain。项目包名继续 `agent_platform`，避免旧项目通用 `src` 冲突。平台新的锁文件需重新求解、环境独立，不能把本轮文档示例当已生成锁。

## 3. 渐进式实施候选

| 切片 | 所属既定步骤 | 精确候选写集/重要文档 | 可运行验收与停止条件 |
|---|---|---|---|
| MP-0 方案评审 | 当前设计轮 | **仅本 llm 目录**，完整方案与基线/审阅 | 用户确认前不实现、不做收费模型请求 |
| MP-1 合同/骨架 | S02 | 拟 platform contracts/domain/application ports、bootstrap、fake driver、合同样例；本目录后续 plan 与 run 记录 | 无外部凭据跑文本/工具/流/错误/幂等/能力拒绝的确定性示例；unsupported 不假成功 |
| MP-2 单厂商与 Bridge | S03 | driver/client pool/Bridge；lib_graph 与 agentmcp 注入点；接入指南 | 真实 DeepSeek 文本/工具/流/结构化验证须在获准额度内；fixture 只能证明合同；旧入口回归 |
| MP-3 第二厂商和替换性 | S03 | 原生协议 driver 或经批准网关驱动；互通报告 | 同一业务用例不改代码切不同协议；缓存 usage/续答/错误映射通过；真实测试需第二家账号/额度 |
| MP-4 多用户账本/限流 | S04 | PG budget/ledger/outbox、Redis admission、API权限、对账与恢复；重要运行/恢复报告 | 跨进程预算争抢、重复入账、发送后崩溃、未知 hold、取消、租户隔离；未通过不开放多用户付费 |
| MP-5 容量与灰度 | S04 完成后 | 目标拓扑/压测工件、灰度/回滚指南 | 50/200/500阶梯和故障注入；真实配额/费用/业务质量分别验收 |
| MP-6 存量批迁移 | 既定 S10 | 旧 SDK/聊天/UI/RAG facade 与视图；逐模块迁移报告 | 新入口只走统一资源端口；未迁移样例保留隔离且不能宣称全仓统一 |

本表细化该专题并交接已存在的步骤，**没有提前改写 S03/S04/S10 的任务合同或状态**。如果决定把持久治理/网关部署提前进 S02，先展示具体范围、依赖和成本变化供用户确认，再改相关 task。当前 S02 根概览保持原有 planned；本轮专题设计不等于 S02 平台实现完成。

## 4. 兼容与可替换性验证

稳定性的实际证明：同一 ModelRequest 和 Harness 用例，依次替换 fake、DeepSeek compatibility driver、原生第二厂商或 gateway driver；业务代码不变，只有 bootstrap/config revision 改变。对必须相同的语义做合同断言：工具 ID、结构化 Schema、事件、错误、未知 usage、终态；输出自然语言质量单独评测，不要求逐字相同。

Manus facade 可以保留 `content/tool_calls/finish_reason`，但不能继续用默认0的 TokenUsage 隐藏未知。迁移时盘点调用方对 `.cost` 浮点格式化和累计计数的依赖，改为 nullable/status-aware 视图或显式兼容错误；这部分不是无损替换，需要独立行为对照和文档。旧业务“失败文本被当成功”、日志含完整 prompts 等问题在迁移边界明确记录，不能把它们归咎于模型更换。

禁止迁移后回调账本、legacy counters 和外部 gateway 同时计供应商成本。老 get_total_usage 若保留，返回新账本的只读投影并注明范围/延迟；不得再成为余额事实。CI 对**已迁移文件集**禁止直接 SDK 构造，不在尚未迁移的全仓强制一刀切导致假完成。

## 5. 灰度、回滚和安全边界

- 按 tenant/用例/model profile 灰度；相同 logical call 只激活一个发送路径。影子对比默认仅比较规范化请求和 fixture，不实际双发收费请求；真实双发须独立额度并明确归因。
- 回滚切换新请求的 active revision，原配置/驱动继续完成在途请求和费用最终化。已经发出的 call 不切回旧 SDK 重发，保持 call/attempt/reservation/receipt 关联。
- 废弃 gateway profile 时先停止新准入、排空/对账，再撤销凭据、释放连接；不删除账本或覆盖历史价格。数据库采用向前兼容迁移，禁用新入口优先于破坏性 downgrade。
- 开发 `.env.local` 仅作现有本地 SecretResolver 的输入候选，实施前重新核对跟踪/权限；生产 secret_ref 接 Secret Manager。普通用户不得设置 base_url、代理地址、HTTP headers 或加载驱动代码。
- 对输出内容只做协议/合同验证；模型层不执行 MCP、eval、Python 或托管外任意工具，保持与后续工具沙箱职责分离。

## 6. 接入完成的判定

只有 public contracts、至少两个不同协议驱动的合同矩阵、Bridge、单一重试 owner、多租户授权/限流/预算/账本和必要故障验证按相应阶段通过，才称“通用多用户模型层可用”。S02 合同骨架完成可以先交付，但不得据此开启没有治理的付费并发。

本轮下一交付是用户对总体设计的评审决定。确认后若进入执行，将在 `docs/task/02-platform-contracts-and-skeleton/run-XX/` 维护思考、行动、复盘、反思并绑定具体授权写集；本轮没有创建工程 Run 或执行 controller。
